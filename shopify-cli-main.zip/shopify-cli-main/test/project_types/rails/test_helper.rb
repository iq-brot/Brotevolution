# frozen_string_literal: true
require "test_helper"

ShopifyCli::ProjectType.load_type(:rails)
