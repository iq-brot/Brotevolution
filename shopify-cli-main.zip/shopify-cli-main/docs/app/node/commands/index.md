---
title: Node.js app commands
redirect_to: https://shopify.dev/tools/cli/reference/node-app
---
