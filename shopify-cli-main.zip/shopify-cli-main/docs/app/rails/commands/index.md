---
title: Ruby on Rails app commands
redirect_to: https://shopify.dev/tools/cli/reference/ruby-on-rails-app
---
