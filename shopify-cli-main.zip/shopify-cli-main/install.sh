# shellcheck shell=sh disable=1012,1001
\cat << 'EOF'
This install method for Shopify CLI is no longer supported.

Please visit this page for complete instructions:
  https://shopify.dev/tools/cli/troubleshooting#migrate-from-a-legacy-version
EOF
